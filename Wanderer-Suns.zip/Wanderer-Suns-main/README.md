# Wanderer-Suns
This is a plugin for Endless Sky that changes to Wanderer reactors so they actually show small "suns" within them.
